//db.js

module.exports={
	url: "mongodb://mik:mik@ds013495.mlab.com:13495/noteit"
};