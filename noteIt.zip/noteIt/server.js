//server.js

const express = require('express');
//use mongo client to interact with your database
const MongoClient = require('mongodb').MongoClient;
const bodyParser= require('body-parser');
//initialize app as an instance of express framework
const app= express();


const db= require('./config/db');
//liste to server on a port
const port= 8000;
app.use(bodyParser.urlencoded({extended:true}));

MongoClient.connect(db.url,(err,database)=>{
	if(err) return console.log(err)
	require('./app/routes')(app,database);

	app.listen(port,()=>{
	console.log('we are live on '+port);
});
})

